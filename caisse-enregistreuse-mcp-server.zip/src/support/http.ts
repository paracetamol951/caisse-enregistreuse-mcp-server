import { fetch, type RequestInit } from 'undici';

export const BASE = process.env.API_BASE || 'https://caisse.enregistreuse.fr';

export function qs(params: Record<string, unknown>) {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
        if (v === undefined || v === null || v === '') continue;
        if (Array.isArray(v)) v.forEach((x) => sp.append(k, String(x)));
        else sp.append(k, String(v));
    }
    return sp.toString();
}

export async function asJsonOrText(res: Response): Promise<String | unknown> {
    const buf = await res.arrayBuffer();
    const txt = new TextDecoder().decode(buf);
    //process.stderr.write(`[caisse][patch] response ${txt} \n`);
    try { return JSON.parse(txt); } catch { return txt; }
}

export async function get(path: string, params: Record<string, unknown>) {
    const url = `${BASE}${path}?${qs(params)}`;
    process.stderr.write(`[caisse][patch] GET ${url} ${path} ${params} \n`);
    const res = await fetch(url);
    return asJsonOrText(res as unknown as Response);
}

export async function postForm(path: string, params: Record<string, unknown>) {
    try {
        process.stderr.write(`[caisse][patch] postForm ${path} \n`);
        process.stderr.write(`[caisse][patch] postForm url ${BASE}${path}?${qs(params)} \n`);

        const controller = new AbortController();
        const to = setTimeout(() => controller.abort(), 15000);

        const res = await fetch(`${BASE}${path}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: qs(params),
            signal: controller.signal
        } as RequestInit).finally(() => clearTimeout(to));
        return asJsonOrText(res as unknown as Response);
    } catch (e) {
        return { error: 'Request failed' };
    }
}

export async function postJsonRaw(path: string, body: unknown, headers: Record<string, string> = {}) {
    try {
        const controller = new AbortController();
        const to = setTimeout(() => controller.abort(), 15000);
        const res = await fetch(`${BASE}${path}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...headers },
            body: JSON.stringify(body),
            signal: controller.signal
        } as RequestInit).finally(() => clearTimeout(to));
        return asJsonOrText(res as unknown as Response);
    } catch (e) {
        return { error: 'Request failed' };
    }
}
